package config

var schemaDataV1 = `{{.schemaV1}}`

var servicesSchemaDataV2 = `{{.schemaV2}}`
