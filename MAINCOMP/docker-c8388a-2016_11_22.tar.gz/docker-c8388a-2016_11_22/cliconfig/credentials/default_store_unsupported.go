// +build !windows,!darwin,!linux

package credentials

const defaultCredentialsStore = ""
