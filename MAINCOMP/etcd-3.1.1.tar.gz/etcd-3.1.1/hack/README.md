Various hacks that are used by developers.
