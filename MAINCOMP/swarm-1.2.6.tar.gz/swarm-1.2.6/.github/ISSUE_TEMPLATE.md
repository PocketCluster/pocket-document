<!-- Before filing an issue, double check that you're in the right repository.

This repository is only for issues related to the standalone Docker Swarm project. 

Issues related to Docker 1.12+ Swarm Mode are filed under the repository:

  github.com/docker/swarmkit

-->
