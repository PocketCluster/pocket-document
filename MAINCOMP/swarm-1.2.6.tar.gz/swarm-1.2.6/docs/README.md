# The docs have been moved!

The documentation for Swarm has been merged into
[the general documentation repo](https://github.com/docker/docker.github.io).

If you'd like to edit the current published version of the Swarm docs,
do it in the master branch here:
https://github.com/docker/docker.github.io/tree/master/swarm

If you need to document the functionality of an upcoming Swarm release,
use the `vnext-swarm` branch:
https://github.com/docker/docker.github.io/tree/vnext-swarm/swarm

As always, the docs in the general repo remain open-source and we appreciate
your feedback and pull requests!
