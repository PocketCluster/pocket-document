#discovery.hub.docker.com

Docker Swarm comes with a simple discovery service built into the [Docker
Hub](http://hub.docker.com). To read the end-user API documentation, visit [the
Swarm discovery documentation on
docs.docker.com](https://docs.docker.com/swarm/discovery/). If you want to
modify the discovery documentation, start with [the `docs/discovery.md`]
