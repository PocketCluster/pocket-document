package experimental

// ENABLED is set to true when the -experimental flag is set.
var ENABLED = false
