# Filters README

The `Docker Swarm` scheduler comes with multiple filters.  To read the end-user
filters documentation, visit [the Swarm API documentation on
docs.docker.com](https://docs.docker.com/swarm/scheduler/filter/).
