# Strategies README

The `Docker Swarm` scheduler comes with multiple strategies.  To read the
end-user strategy documentation, visit [the Swarm strategy documentation on
docs.docker.com](https://docs.docker.com/swarm/scheduler/strategy/).
